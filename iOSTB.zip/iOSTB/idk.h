//
//  idk.h
//  iOSTB
//
//  Created by Doc Aiden on 12/21/17.
//  Copyright © 2017 iDoc. All rights reserved.
//

#ifndef idk_h
#define idk_h

const char *injekt = "";
#endif /* idk_h */
