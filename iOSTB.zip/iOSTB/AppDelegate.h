//
//  AppDelegate.h
//  iOSTB
//
//  Created by Doc Aiden on 12/16/17.
//  Copyright © 2017 iDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

