#ifndef async_wake_h
#define async_wake_h

#include <stdio.h>

mach_port_t get_tfp0(mach_port_t*uc);

#endif /* async_wake_h */
