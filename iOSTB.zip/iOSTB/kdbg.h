#ifndef kdbg_h
#define kdbg_h

void test_kernel_bp(void);
uint64_t pin_current_thread(void);
void test_kdbg(void);
void test_fp(void);

#endif
